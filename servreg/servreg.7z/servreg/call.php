<?php
echo file_get_contents('http://localhost/gexplor/viuserv/server.php');